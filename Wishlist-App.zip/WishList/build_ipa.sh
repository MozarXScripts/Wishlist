#!/bin/bash
# Builds Wishlist.ipa (with the Payload folder) on a Mac. Free, no paid Apple account.
set -e
cd "$(dirname "$0")"

if ! command -v xcodegen >/dev/null; then
  echo "Installing XcodeGen (free)..."
  brew install xcodegen
fi

xcodegen generate

xcodebuild \
  -project Wishlist.xcodeproj \
  -scheme Wishlist \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build

rm -rf Payload Wishlist.ipa
mkdir Payload
cp -R build/Build/Products/Release-iphoneos/Wishlist.app Payload/
zip -qr Wishlist.ipa Payload

echo ""
echo "Done: $(pwd)/Wishlist.ipa"
echo "Open Sideloadly or AltStore, sign in with your free Apple ID, and install it."
