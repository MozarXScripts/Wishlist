# Wishlist app: build the IPA with no Mac (free)

GitHub builds the app for you on a free cloud Mac.

## Steps
1. Make a free account at github.com and create a **new public repository** (public repos get free Mac build time).
2. Upload everything in this folder to it, including the hidden `.github` folder. If the `.github` folder won't upload, use Add file > Create new file, name it `.github/workflows/build.yml`, and paste in the contents of that file.
3. Open the repo's **Actions** tab. The "Build IPA" run starts by itself (or click it, then "Run workflow").
4. After about 5 minutes, open the finished run and download **Wishlist-ipa** under Artifacts. Unzip it to get `Wishlist.ipa`.

## Installing it on your iPhone (free, works on Windows)
The IPA is unsigned. Install **Sideloadly** (sideloadly.io), plug in your iPhone, drag in `Wishlist.ipa`, and sign in with your free Apple ID. Free signing lasts 7 days, so repeat weekly.

## If you do have a Mac
Run `./build_ipa.sh` in this folder.

## Notifications
The app posts to ntfy.sh (free). A parent installs the "ntfy" app and subscribes to the family code on the Parents tab.
