import SwiftUI
import SafariServices

struct WebLink: Identifiable {
    let id = UUID()
    let url: URL
}

struct SafariView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }
    func updateUIViewController(_ vc: SFSafariViewController, context: Context) {}
}

struct Store: Identifiable {
    let id = UUID()
    let name: String
    let icon: String
    let base: String
}

struct AddItemView: View {
    @EnvironmentObject var store: WishStore
    @Environment(\.dismiss) private var dismiss

    @State var occasion: Occasion
    @State private var name = ""
    @State private var note = ""
    @State private var price = ""
    @State private var link = ""
    @State private var web: WebLink?

    init(defaultOccasion: Occasion) {
        _occasion = State(initialValue: defaultOccasion)
    }

    private let stores: [Store] = [
        Store(name: "Amazon", icon: "cart.fill", base: "https://www.amazon.com/s?k="),
        Store(name: "Target", icon: "target", base: "https://www.target.com/s?searchTerm="),
        Store(name: "Walmart", icon: "bag.fill", base: "https://www.walmart.com/search?q="),
        Store(name: "Google", icon: "magnifyingglass", base: "https://www.google.com/search?tbm=shop&q=")
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("What do you want?") {
                    TextField("e.g. LEGO Millennium Falcon", text: $name)
                    TextField("Notes (color, size...)", text: $note)
                }

                Section("Find it online") {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(stores) { s in
                                Button { open(s) } label: {
                                    Label(s.name, systemImage: s.icon)
                                        .font(.subheadline.weight(.semibold))
                                        .padding(.horizontal, 14).padding(.vertical, 10)
                                        .background(Color.accentColor.opacity(0.12), in: Capsule())
                                }
                                .buttonStyle(.plain)
                                .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                            }
                        }
                    }
                    HStack {
                        TextField("Paste product link", text: $link)
                            .textInputAutocapitalization(.never)
                            .keyboardType(.URL)
                            .autocorrectionDisabled()
                        Button("Paste") {
                            if let s = UIPasteboard.general.string { link = s }
                        }
                    }
                    TextField("Price (optional)", text: $price)
                    Text("Tip: in the store page, tap the share button, choose Copy, then come back and tap Paste.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Occasion") {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(Occasion.allCases) { o in
                                Button { occasion = o } label: {
                                    OccasionChip(title: o.title, emoji: o.emoji,
                                                 color: o.color, selected: occasion == o)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .navigationTitle("New Wish")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") { save() }
                        .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                        .fontWeight(.bold)
                }
            }
            .sheet(item: $web) { w in
                SafariView(url: w.url).ignoresSafeArea()
            }
        }
    }

    private func open(_ s: Store) {
        let q = name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? name
        if let url = URL(string: s.base + q) { web = WebLink(url: url) }
    }

    private func save() {
        var urlString = link.trimmingCharacters(in: .whitespacesAndNewlines)
        if !urlString.isEmpty && !urlString.lowercased().hasPrefix("http") {
            urlString = "https://" + urlString
        }
        let item = WishItem(
            name: name.trimmingCharacters(in: .whitespaces),
            note: note,
            urlString: urlString,
            price: price,
            occasion: occasion
        )
        store.add(item)
        dismiss()
    }
}
