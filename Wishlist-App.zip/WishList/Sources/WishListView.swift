import SwiftUI

struct OccasionChip: View {
    let title: String
    let emoji: String
    let color: Color
    let selected: Bool

    var body: some View {
        HStack(spacing: 6) {
            Text(emoji)
            Text(title).font(.subheadline.weight(.semibold))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .background(selected ? color : color.opacity(0.12), in: Capsule())
        .foregroundStyle(selected ? .white : color)
    }
}

struct WishCard: View {
    let item: WishItem

    var body: some View {
        HStack(spacing: 14) {
            Text(item.occasion.emoji)
                .font(.system(size: 30))
                .frame(width: 58, height: 58)
                .background(item.occasion.color.opacity(0.15),
                            in: RoundedRectangle(cornerRadius: 16))

            VStack(alignment: .leading, spacing: 5) {
                Text(item.name)
                    .font(.headline)
                    .strikethrough(item.isGot)
                if !item.note.isEmpty {
                    Text(item.note)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                HStack(spacing: 8) {
                    if !item.price.isEmpty {
                        Text(item.price)
                            .font(.caption.weight(.bold))
                            .padding(.horizontal, 8).padding(.vertical, 3)
                            .background(.green.opacity(0.15), in: Capsule())
                            .foregroundStyle(.green)
                    }
                    Text(item.occasion.title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            if item.isGot {
                Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
            } else if !item.urlString.isEmpty, let url = URL(string: item.urlString) {
                Link(destination: url) {
                    Image(systemName: "arrow.up.right.circle.fill")
                        .font(.title2)
                }
            }
        }
        .padding(14)
        .background(Color(.secondarySystemGroupedBackground),
                    in: RoundedRectangle(cornerRadius: 22))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
        .opacity(item.isGot ? 0.6 : 1)
    }
}

struct WishListView: View {
    @EnvironmentObject var store: WishStore
    @State private var filter: Occasion? = nil
    @State private var showAdd = false

    private var filtered: [WishItem] {
        guard let filter else { return store.items }
        return store.items.filter { $0.occasion == filter }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            Button { filter = nil } label: {
                                OccasionChip(title: "All", emoji: "✨", color: .indigo, selected: filter == nil)
                            }
                            ForEach(Occasion.allCases) { o in
                                Button { filter = o } label: {
                                    OccasionChip(title: o.title, emoji: o.emoji, color: o.color, selected: filter == o)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    .listRowInsets(EdgeInsets())
                    .listRowBackground(Color.clear)
                }

                if filtered.isEmpty {
                    VStack(spacing: 10) {
                        Text("🎅").font(.system(size: 60))
                        Text("Nothing here yet")
                            .font(.title3.bold())
                        Text("Tap + to add your first wish.")
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 50)
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                } else {
                    ForEach(filtered) { item in
                        WishCard(item: item)
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                            .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) { store.delete(item) } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button { store.toggleGot(item) } label: {
                                    Label(item.isGot ? "Undo" : "Got it", systemImage: "checkmark")
                                }
                                .tint(.green)
                            }
                    }
                }
            }
            .listStyle(.plain)
            .background(Color(.systemGroupedBackground))
            .navigationTitle("\(store.childName)'s Wishes")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showAdd = true } label: {
                        Image(systemName: "plus.circle.fill").font(.title2)
                    }
                }
            }
            .sheet(isPresented: $showAdd) {
                AddItemView(defaultOccasion: filter ?? .christmas)
            }
        }
    }
}
