import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var store: WishStore
    @State private var name = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            LinearGradient(colors: [.red, .orange, .pink],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 28) {
                Spacer()
                Text("🎁")
                    .font(.system(size: 90))
                Text("Wishlist")
                    .font(.system(size: 44, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                Text("Save everything you want for birthdays, holidays and more. Your parents get a ping when you add something.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.9))
                    .padding(.horizontal, 32)

                VStack(spacing: 14) {
                    TextField("What's your name?", text: $name)
                        .focused($focused)
                        .padding()
                        .background(.white, in: RoundedRectangle(cornerRadius: 16))
                        .foregroundStyle(.black)
                        .submitLabel(.go)
                        .onSubmit(start)

                    Button(action: start) {
                        Text("Let's go!")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.black.opacity(name.isEmpty ? 0.25 : 0.8),
                                        in: RoundedRectangle(cornerRadius: 16))
                            .foregroundStyle(.white)
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding(.horizontal, 32)
                Spacer()
            }
        }
    }

    private func start() {
        guard !name.trimmingCharacters(in: .whitespaces).isEmpty else { return }
        store.completeSetup(name: name)
    }
}
