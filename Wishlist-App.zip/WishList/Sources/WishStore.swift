import SwiftUI

struct Snapshot: Codable {
    var childName: String
    var topic: String
    var items: [WishItem]
    var onboarded: Bool
}

@MainActor
final class WishStore: ObservableObject {
    @Published var childName = ""
    @Published var topic = ""
    @Published var items: [WishItem] = []
    @Published var onboarded = false

    private let key = "wishlist.snapshot.v1"

    init() { load() }

    // MARK: Persistence

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let snap = try? JSONDecoder().decode(Snapshot.self, from: data) else { return }
        childName = snap.childName
        topic = snap.topic
        items = snap.items
        onboarded = snap.onboarded
    }

    private func save() {
        let snap = Snapshot(childName: childName, topic: topic, items: items, onboarded: onboarded)
        if let data = try? JSONEncoder().encode(snap) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    // MARK: Actions

    func completeSetup(name: String) {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        childName = clean
        let letters = clean.lowercased().filter { $0.isLetter && $0.isASCII }
        let suffix = String((0..<8).map { _ in "abcdefghijklmnopqrstuvwxyz0123456789".randomElement()! })
        topic = "wishlist-\(letters)-\(suffix)"
        onboarded = true
        save()
    }

    func add(_ item: WishItem) {
        items.insert(item, at: 0)
        save()
        let name = childName
        let topic = topic
        Task {
            await Notifier.send(
                topic: topic,
                title: "\(name) added a wish \(item.occasion.emoji)",
                message: "\(name) added \"\(item.name)\" to their \(item.occasion.title) list."
                    + (item.price.isEmpty ? "" : " (\(item.price))"),
                link: item.urlString
            )
        }
    }

    func toggleGot(_ item: WishItem) {
        guard let i = items.firstIndex(of: item) else { return }
        items[i].isGot.toggle()
        save()
    }

    func delete(_ item: WishItem) {
        items.removeAll { $0.id == item.id }
        save()
    }

    func sendTest() {
        let name = childName
        let topic = topic
        Task {
            await Notifier.send(topic: topic,
                                title: "Test from \(name)'s wish list 🎁",
                                message: "If you can read this, notifications are working!")
        }
    }

    func reset() {
        UserDefaults.standard.removeObject(forKey: key)
        childName = ""; topic = ""; items = []; onboarded = false
    }

    var inviteText: String {
        """
        Hi! I made a wish list. To get a notification whenever I add something:
        1. Install the free "ntfy" app from the App Store
        2. Tap + and subscribe to this topic: \(topic)
        """
    }
}
