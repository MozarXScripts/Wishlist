import SwiftUI

@main
struct WishListApp: App {
    @StateObject private var store = WishStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .tint(.red)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: WishStore

    var body: some View {
        if store.onboarded {
            TabView {
                WishListView()
                    .tabItem { Label("My Wishes", systemImage: "gift.fill") }
                ParentsView()
                    .tabItem { Label("Parents", systemImage: "bell.badge.fill") }
            }
        } else {
            OnboardingView()
        }
    }
}
