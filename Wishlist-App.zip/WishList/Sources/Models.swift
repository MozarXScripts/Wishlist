import SwiftUI

enum Occasion: String, Codable, CaseIterable, Identifiable {
    case christmas, birthday, hanukkah, easter, justBecause

    var id: String { rawValue }

    var title: String {
        switch self {
        case .christmas: return "Christmas"
        case .birthday: return "Birthday"
        case .hanukkah: return "Hanukkah"
        case .easter: return "Easter"
        case .justBecause: return "Just Because"
        }
    }

    var emoji: String {
        switch self {
        case .christmas: return "🎄"
        case .birthday: return "🎂"
        case .hanukkah: return "🕎"
        case .easter: return "🐣"
        case .justBecause: return "🎁"
        }
    }

    var color: Color {
        switch self {
        case .christmas: return .red
        case .birthday: return .pink
        case .hanukkah: return .blue
        case .easter: return .purple
        case .justBecause: return .orange
        }
    }
}

struct WishItem: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var note: String = ""
    var urlString: String = ""
    var price: String = ""
    var occasion: Occasion
    var isGot: Bool = false
    var addedAt = Date()
}
