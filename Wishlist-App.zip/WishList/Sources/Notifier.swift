import Foundation

/// Sends free push notifications to a parent through ntfy.sh.
/// The parent installs the free "ntfy" app and subscribes to the family topic.
enum Notifier {
    private struct Payload: Encodable {
        let topic: String
        let title: String
        let message: String
        let tags: [String]
        let click: String?
    }

    static func send(topic: String, title: String, message: String, link: String? = nil) async {
        guard !topic.isEmpty, let url = URL(string: "https://ntfy.sh") else { return }
        let payload = Payload(
            topic: topic,
            title: title,
            message: message,
            tags: ["gift"],
            click: (link?.isEmpty == false) ? link : nil
        )
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(payload)
        _ = try? await URLSession.shared.data(for: request)
    }
}
