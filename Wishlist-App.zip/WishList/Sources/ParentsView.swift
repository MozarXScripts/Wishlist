import SwiftUI

struct ParentsView: View {
    @EnvironmentObject var store: WishStore
    @State private var copied = false
    @State private var confirmReset = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("🔔 Get notified")
                            .font(.title3.bold())
                        Text("Parents get a push notification every time \(store.childName) adds a wish. It uses the free ntfy app.")
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 6)
                }

                Section("Parent setup") {
                    Label("Install the free “ntfy” app", systemImage: "1.circle.fill")
                    Label("Tap + and subscribe to the code below", systemImage: "2.circle.fill")
                    Label("Allow notifications. Done!", systemImage: "3.circle.fill")
                }

                Section("Family code") {
                    Text(store.topic)
                        .font(.system(.body, design: .monospaced))
                        .textSelection(.enabled)
                    Button {
                        UIPasteboard.general.string = store.topic
                        copied = true
                    } label: {
                        Label(copied ? "Copied!" : "Copy code", systemImage: "doc.on.doc")
                    }
                    ShareLink(item: store.inviteText) {
                        Label("Send invite to a parent", systemImage: "square.and.arrow.up")
                    }
                    Button { store.sendTest() } label: {
                        Label("Send test notification", systemImage: "paperplane.fill")
                    }
                }

                Section {
                    Text("Anyone with the code can see notifications, so only share it with family.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Reset app", role: .destructive) { confirmReset = true }
                }
            }
            .navigationTitle("Parents")
            .confirmationDialog("Erase all wishes and start over?",
                                isPresented: $confirmReset, titleVisibility: .visible) {
                Button("Erase everything", role: .destructive) { store.reset() }
            }
        }
    }
}
